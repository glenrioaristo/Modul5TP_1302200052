﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TPmodul5_1302200052
{
    internal class SayaTubeVideo
    {
        private int id, playCount;
        private string title;

        public SayaTubeVideo (string title)
        {
            try
            {
                if (this.title != null && title.Length < 20)
                {
                    Random rndm = new Random();
                    id = rndm.Next(10000, 99999);//returns random integers < 99999
                    playCount = 0;
                    this.title = title;
                }
            }
            catch (Exception)
            {
                Console.WriteLine("terlalu banyak karakter");
                
            }

        }

        public void IncreasePlayCount(int x)
        {
            try
            {
                if (x < 100000000)
                {
                    this.playCount = x;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            
        }

        public void PrintVideoDetails()
        {
            Console.WriteLine("ID :"+id +", Judul :"+ title +", Jumlah play :"+ playCount);
        }
    }
}
